# 无名微博客PHP版

#### 介绍
无名微博客PHP版,欢迎测试提供BUG。

#### 软件架构
采用php编写，数据库采用sqlite


#### 安装教程

1. 下载
2. 解压
3. 使用

#### 使用说明

1. 默认密码：admin
2. 配置文件：app/class/config.php
3. 演示网站：http://demo.semlog.cn/index.html
