# 无名微博客PHP版

#### 介绍
无名轻博客v1.0正式版发布
运行环境：PHP>=5.4 pdo_sqlite
更新如下：
修改时间使用laydate插件，日期修改更加清晰明了
调整了模板目录结构，使得更换模板更容易，结构也更清晰。
增加日期友好显示
一些细微调整小BUG修复
使用前请修改密码
1、默认密码：admin
2、配置文件：app/class/config.php



#### 安装教程

1. 下载 https://gitee.com/daimaguo/wmphp/blob/master/qblog.zip
2. 解压
3. 使用

#### 官网及演示

官方网站：https://www.4jax.net/log
演示网站：http://demo.semlog.cn/

欢迎体验使用提交BUG及建议。